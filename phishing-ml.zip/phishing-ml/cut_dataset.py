import pandas as pd
from scipy.io import arff

# đọc file gốc
data, meta = arff.loadarff("dataset.arff")
df = pd.DataFrame(data)

# chuyển sang int
df = df.apply(lambda col: col.astype(int))

# chọn 15 feature (giống mình đã chọn cho bạn)
selected_columns = [
    "having_IP_Address",
    "URL_Length",
    "Shortining_Service",
    "having_At_Symbol",
    "double_slash_redirecting",
    "Prefix_Suffix",
    "having_Sub_Domain",
    "SSLfinal_State",
    "Domain_registeration_length",
    "Request_URL",
    "URL_of_Anchor",
    "Links_in_tags",
    "SFH",
    "web_traffic",
    "Google_Index",
    "Result"
]

df_new = df[selected_columns]

# ghi ra file arff mới
with open("dataset_15.arff", "w") as f:
    f.write("@relation phishing\n\n")

    f.write("@attribute having_IP_Address { -1,1 }\n")
    f.write("@attribute URL_Length { 1,0,-1 }\n")
    f.write("@attribute Shortining_Service { 1,-1 }\n")
    f.write("@attribute having_At_Symbol { 1,-1 }\n")
    f.write("@attribute double_slash_redirecting { -1,1 }\n")
    f.write("@attribute Prefix_Suffix { -1,1 }\n")
    f.write("@attribute having_Sub_Domain { -1,0,1 }\n")
    f.write("@attribute SSLfinal_State { -1,1,0 }\n")
    f.write("@attribute Domain_registeration_length { -1,1 }\n")
    f.write("@attribute Request_URL { 1,-1 }\n")
    f.write("@attribute URL_of_Anchor { -1,0,1 }\n")
    f.write("@attribute Links_in_tags { 1,-1,0 }\n")
    f.write("@attribute SFH { -1,1,0 }\n")
    f.write("@attribute web_traffic { -1,0,1 }\n")
    f.write("@attribute Google_Index { 1,-1 }\n")
    f.write("@attribute Result { -1,1 }\n\n")

    f.write("@data\n")

    for _, row in df_new.iterrows():
        line = ",".join(map(str, row.values))
        f.write(line + "\n")

print("Đã tạo file dataset_15.arff thành công!")